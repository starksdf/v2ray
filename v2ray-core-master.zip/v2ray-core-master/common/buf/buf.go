// Package buf provides a light-weight memory allocation mechanism.
package buf // import "v2ray.com/core/common/buf"

//go:generate go run v2ray.com/core/common/errors/errorgen
