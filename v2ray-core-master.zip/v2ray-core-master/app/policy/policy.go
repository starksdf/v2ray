// Package policy is an implementation of policy.Manager feature.
package policy

//go:generate go run v2ray.com/core/common/errors/errorgen
